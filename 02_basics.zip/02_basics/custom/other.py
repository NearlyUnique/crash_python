def other_function():
    pass

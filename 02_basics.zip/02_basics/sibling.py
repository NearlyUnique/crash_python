def my_function():
    '''A comment to explain my function in case I forget'''
    print("my function in another file")